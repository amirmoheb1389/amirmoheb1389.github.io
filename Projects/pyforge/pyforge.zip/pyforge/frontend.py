import turtle
turtle.title("pyforge")
def back_color(color,name):
    return name.bgcolor(color)
def back_image(image):
    return turtle.bgpic(image)
def title(title):
    return turtle.title(title)
def window():
    return turtle.Screen()
def window_size(name,x , y):
    return name.setup(x, y)
def car():
    return turtle.Turtle()
def car_color(name, color):
    return name.color(color)
def car_shape(name, met, shape):
    if met == "shape":
        return name.shape(shape)
    elif met == "image":
        return name.shape(shape)
def car_size(w, l, name):
    return name.turtlesize(tretch_wid=w, stretch_len=l)
def car_pen_setting(color, size, name):
    return name.pencolor(color),name.pensize(size)
def text(text,font,location,name):
    return name.write(text,font,location)
def completed():
    return turtle.done()
def shape(name,r,amount,side):
    return name.circle(r,(amount * 360),side)